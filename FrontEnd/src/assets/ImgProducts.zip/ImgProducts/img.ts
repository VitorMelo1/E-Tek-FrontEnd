import PS5 from "./PS5.png";
import CelularIphone from "./CeleularIphone.png";
import Camera from "./Camera.png";
import TvSmart from "./TvSmart.png";
import CelularSamsung from "./CelularSamsung.png";

const img = {
  PS5,
  Camera,
  TvSmart,
  CelularIphone,
  CelularSamsung,
};
export default img;