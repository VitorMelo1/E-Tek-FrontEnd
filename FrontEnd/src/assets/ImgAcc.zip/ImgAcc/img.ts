import Volante from "./volante.png";
import Base from "./base carregadora dualsense.png"
import Controle from "./dualsense branco.png"
import Headseat from "./headset gamer ps5 pro.png"
import SSD from "./SSD expansivo ps5.png"
import HD from "./HD ps5 branco.png"
import Capa from "./capa protetora ps5.png"

const img = {
  Volante,
  Base,
Controle,
Headseat,
SSD,
HD,
Capa,
};
export default img;